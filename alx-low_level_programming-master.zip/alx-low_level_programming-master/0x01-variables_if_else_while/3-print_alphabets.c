#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
	char c;

	for (c = 97 ; c < 123 ; c++)
	{
	putchar(c);
	}
	for (c = 65 ; c < 91 ; c++)
	{
	putchar(c);
	}
	putchar('\n');

return (0);
}
