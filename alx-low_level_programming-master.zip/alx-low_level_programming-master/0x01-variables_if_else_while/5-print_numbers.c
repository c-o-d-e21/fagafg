#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
	int c;

	for (c = 0 ; c < 10 ; c++)
	{
		printf("%i", c);
	}
	printf("\n");

return (0);
}
