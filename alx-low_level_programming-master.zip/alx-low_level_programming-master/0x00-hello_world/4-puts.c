
#include <stdio.h>
/**
 * main - use printf typeof
 * Description: output with printf
 * Return: 0
 */
int main(void)
{
puts("\"Programming is like building a multilingual puzzle");
return (0);
}
