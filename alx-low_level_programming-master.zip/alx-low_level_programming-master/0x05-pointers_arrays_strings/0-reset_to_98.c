#include "main.h"

/**
 * reset_to_98 - check the code for ALX School students.
 * @n: pass in pointers
 * Return: Always 0.
 */
void reset_to_98(int *n)
{
	*n = 98;
}
