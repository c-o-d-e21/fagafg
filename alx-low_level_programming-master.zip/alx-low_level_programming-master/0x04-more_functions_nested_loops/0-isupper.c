#include "main.h"
/**
 * _isupper - stat from here
 * Return: 0 or 1
 * @c: char to check for upper or lower
 */

int _isupper(int c)
{
return (c >= 'A' && c <= 'Z');
}
