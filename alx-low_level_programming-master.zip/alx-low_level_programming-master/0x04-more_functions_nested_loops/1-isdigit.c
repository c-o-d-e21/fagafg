#include "main.h"
/**
 * _isdigit - stat from here
 * Return: 0 or 1
 * @c: char to check for upper or lower
 */

int _isdigit(int c)
{
return (c >= '0' && c <= '9');
}
