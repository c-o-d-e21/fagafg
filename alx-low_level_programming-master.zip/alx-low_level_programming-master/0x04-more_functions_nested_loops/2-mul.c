#include "main.h"

/**
 * mul - multiplies two integers
 * @a: first integer
 * @b: second integer
 *
 * Return: multiplication of a and b
 */

int mul(int a, int b)
{
	return (b * a);
}
