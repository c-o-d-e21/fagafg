#include <stdio.h>

int test;

/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
int i;
	int j;
	int arr = {1, 2, 3};
	int k;

	putchar('\n');
	return (0);
}
