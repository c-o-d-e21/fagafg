void func0(int var1, int var2)
{
	var1 = var2;
	/* --- */
	var1 = var2 + var2;
	/* --- */
	var1 = var2 - var2;
	/* --- */
	var1 = var2 < var1;
	/* --- */
	var1 = var2 > var1;
	/* --- */
	var1 = var2 * var1;
	/* --- */
	var1 = var2 / var1;
	/* --- */
	var1 = var2 % var1;
	/* --- */
	var1 = var2 % var1;
}

void func1(int var1, int var2)
{
	var1 = var2 | var1;
	/* --- */
	var1 = var2 & var1;
	/* --- */
	var1 = var2 ^ var1;
	/* --- */
	var1 = var2 <= var1;
	/* --- */
	var1 = var2 >= var1;
	/* --- */
	var1 = var2 == var1;
	/* --- */
	var1 = var2 != var1;
}

void func2(int var1, int var2)
{
	var1 = var2 << 1;
	/* --- */
	var1 = var2 >> 1;
}

void func3(int var1, int var2)
{
	var1 = var2 > 0 ? var1 : var2;
}

void func4(int var1, int var2)
{
	var1 += var2;
	/* --- */
	var1 -= var2;
	/* --- */
	var1 *= var2;
	/* --- */
	var1 /= var2;
	/* --- */
	var1 %= var2;
	/* --- */
	var1 &= var2;
	/* --- */
	var1 |= var2;
	/* --- */
	var1 ^= var2;
	/* --- */
	var1 >>= var2;
	/* --- */
	var1 <<= var2;
}
