/**
 * alloc_grid - Aloocates a grid
 *
 * @width: Width
 * @height: Height
 *
 * Return: The allocated grid
 */
int **alloc_grid(int width, int height)
{
	return ((void *)0);
}
