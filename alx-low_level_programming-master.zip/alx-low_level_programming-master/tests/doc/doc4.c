/**
 * print_chessboard - Prints a board
 *
 * @a: The board to be printed
 *
 * Return: 0
 */
int print_chessboard(char (*a)[8])
{
	return (0);
}
