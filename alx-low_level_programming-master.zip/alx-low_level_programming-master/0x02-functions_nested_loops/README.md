C-functions, nested loops
