#include "main.h"
/**
 * _islower - Entry point
 * Return: true or false
 * @c : check
 */
int _islower(int c)
{
	return (c >= 'a' && c <= 'z');

}
