#include "main.h"

/**
 * main - tests if function prints a negative or positive integer
 * Return: 0
 */

int main(void)
{
	int i;

	i = 0;
	positive_or_negative(i);

	return (0);
}
